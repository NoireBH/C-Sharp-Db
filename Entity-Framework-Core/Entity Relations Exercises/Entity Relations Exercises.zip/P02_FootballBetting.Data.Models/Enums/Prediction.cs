﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Data.Models.Enums;

public enum Prediction
{
    Win = 0,
    Loss = 1,
    Tie = 2,
}
