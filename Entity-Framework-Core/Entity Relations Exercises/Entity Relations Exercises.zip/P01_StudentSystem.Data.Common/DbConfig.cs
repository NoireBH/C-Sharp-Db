﻿namespace P01_StudentSystem.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";
    }
}