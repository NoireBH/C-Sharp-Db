﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=FootBallBetting;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";
    }
}