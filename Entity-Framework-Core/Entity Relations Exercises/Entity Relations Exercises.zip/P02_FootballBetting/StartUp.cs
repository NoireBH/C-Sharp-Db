﻿using P02_FootballBetting.Data;

var context = new FootballBettingContext();

context.Database.EnsureCreated();