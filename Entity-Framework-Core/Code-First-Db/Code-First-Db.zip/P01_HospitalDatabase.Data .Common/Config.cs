﻿namespace P01_HospitalDatabase.Data_.Common
{
    public class Config
    {
        public static string ConnectionString =
            @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=Hospital;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";
    }
}