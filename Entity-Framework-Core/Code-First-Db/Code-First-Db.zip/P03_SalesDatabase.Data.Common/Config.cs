﻿namespace P03_SalesDatabase.Data.Common
{
    public class Config
    {
        public static string ConnectionString =
            @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=Sales;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";
    }
}