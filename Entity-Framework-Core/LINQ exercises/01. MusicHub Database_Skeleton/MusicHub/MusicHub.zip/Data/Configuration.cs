﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=MusicHub;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";
    }
}
