﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False;TrustServerCertificate=True";
	}
}
