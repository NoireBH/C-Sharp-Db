﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-84CHDHM\SQLEXPRESS;Database=SoftJail;Integrated Security=True;Encrypt=False;";
    }
}
